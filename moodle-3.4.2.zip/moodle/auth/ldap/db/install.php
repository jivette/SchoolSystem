<?php

function xmldb_auth_ldap_install() {
    global $CFG, $DB;

}
